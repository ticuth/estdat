﻿namespace Skins
{
    partial class FrmConfig
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.chkFade = new System.Windows.Forms.CheckBox();
            this.chkTransparent = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // chkFade
            // 
            this.chkFade.AutoSize = true;
            this.chkFade.Location = new System.Drawing.Point(12, 12);
            this.chkFade.Name = "chkFade";
            this.chkFade.Size = new System.Drawing.Size(50, 17);
            this.chkFade.TabIndex = 0;
            this.chkFade.Text = "Fade";
            this.chkFade.UseVisualStyleBackColor = true;
            this.chkFade.CheckedChanged += new System.EventHandler(this.chkFade_CheckedChanged);
            // 
            // chkTransparent
            // 
            this.chkTransparent.AutoSize = true;
            this.chkTransparent.Checked = true;
            this.chkTransparent.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkTransparent.Location = new System.Drawing.Point(68, 12);
            this.chkTransparent.Name = "chkTransparent";
            this.chkTransparent.Size = new System.Drawing.Size(83, 17);
            this.chkTransparent.TabIndex = 1;
            this.chkTransparent.Text = "Transparent";
            this.chkTransparent.UseVisualStyleBackColor = true;
            this.chkTransparent.CheckedChanged += new System.EventHandler(this.chkTransparent_CheckedChanged);
            // 
            // FrmConfig
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(155, 39);
            this.Controls.Add(this.chkTransparent);
            this.Controls.Add(this.chkFade);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "FrmConfig";
            this.Text = "Config.";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmConfig_FormClosing);
            this.Load += new System.EventHandler(this.FrmConfig_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox chkFade;
        private System.Windows.Forms.CheckBox chkTransparent;
    }
}