﻿namespace Skins
{
    partial class FrmConfig2
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.cboFade = new System.Windows.Forms.ComboBox();
            this.cboTransparent = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Fade";
            // 
            // cboFade
            // 
            this.cboFade.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboFade.FormattingEnabled = true;
            this.cboFade.Items.AddRange(new object[] {
            "NO",
            "YES"});
            this.cboFade.Location = new System.Drawing.Point(101, 23);
            this.cboFade.Name = "cboFade";
            this.cboFade.Size = new System.Drawing.Size(121, 21);
            this.cboFade.TabIndex = 1;
            this.cboFade.SelectedIndexChanged += new System.EventHandler(this.cboFade_SelectedIndexChanged);
            // 
            // cboTransparent
            // 
            this.cboTransparent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTransparent.FormattingEnabled = true;
            this.cboTransparent.Items.AddRange(new object[] {
            "NO",
            "YES"});
            this.cboTransparent.Location = new System.Drawing.Point(101, 50);
            this.cboTransparent.Name = "cboTransparent";
            this.cboTransparent.Size = new System.Drawing.Size(121, 21);
            this.cboTransparent.TabIndex = 3;
            this.cboTransparent.SelectedIndexChanged += new System.EventHandler(this.cboTransparent_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Transparent";
            // 
            // FrmConfig2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(279, 113);
            this.Controls.Add(this.cboTransparent);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cboFade);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "FrmConfig2";
            this.Text = "Config. 2";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmConfig2_FormClosing);
            this.Load += new System.EventHandler(this.FrmConfig2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cboFade;
        private System.Windows.Forms.ComboBox cboTransparent;
        private System.Windows.Forms.Label label2;
    }
}