﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoValidar
{

    /// <summary>
    /// Valida con encapsulamiento
    /// </summary>
    class ValidandoConEncapsulamiento
    {
        /// <summary>
        /// Nombre a guardar
        /// </summary>
        private string _nombre;

        /// <summary>
        /// Constructor de ValidandoConEncapsulamiento
        /// </summary>
        public ValidandoConEncapsulamiento()
        {
            _nombre = "";
        }

        /// <summary>
        /// Asigna un valor, pero valida
        /// </summary>
        /// <param name="valor">Valor a guardar</param>
        /// <returns>ManejoError para saber si hay error y cual</returns>
        public ManejoError setNombre(string valor)
        {
            ManejoError m = new ManejoError();

            if (valor.Length >= 3)
            {
                _nombre = valor;
            }
            else
            {
                m.setError("Minimo 3 letras");
            }

            return m;
        }


        /// <summary>
        /// Regresa el nombre guardado
        /// </summary>
        /// <returns>Regresa el nombre guardado</returns>
        public string getNombre()
        {
            return _nombre;
        }
    }
}
