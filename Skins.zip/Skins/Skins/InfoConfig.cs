﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Skins
{
    class InfoConfig
    {
        
        private bool fade;
        private bool transparent;
        List<IObserver> observers;
        public InfoConfig()
        {
            observers = new List<IObserver>();
        }
        public void addObserver(IObserver io)
        {
            observers.Add(io);
        }
        public void removeObserver(IObserver io)
        {
            observers.Remove(io);
        }

        private static InfoConfig instance;
        public static InfoConfig getInstance()
        {
            if (instance == null)
            {
                instance = new InfoConfig();
            }
            return instance;
        }


        public void setFade(object who, bool value)
        {
            fade = value;
            alertAll(who);
        }
        private void alertAll(object sender)
        {
            foreach (IObserver io in observers)
            {
                if (io != sender)
                {
                    io.changed(sender);
                }
            }
        }
        public bool isFade()
        {
            return fade;
        }
        public void setTransparent(object who, bool value)
        {
            transparent = value;
            alertAll(who);
        }
        public bool isTransparent()
        {
            return transparent;
        }
    }
}
