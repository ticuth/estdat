﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EducApp
{
    public interface INotify
    {
        void updated();
        void connectedTo(INotifier sender);
    }
}
