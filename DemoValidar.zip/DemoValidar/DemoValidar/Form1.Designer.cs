﻿namespace DemoValidar
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.btnGuardarSE = new System.Windows.Forms.Button();
            this.btnMostrarSE = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnMostrarCE = new System.Windows.Forms.Button();
            this.btnGuardarCE = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnMostrarVCE = new System.Windows.Forms.Button();
            this.btnGuardarVCE = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nombre:";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(15, 25);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(247, 20);
            this.txtNombre.TabIndex = 1;
            // 
            // btnGuardarSE
            // 
            this.btnGuardarSE.Location = new System.Drawing.Point(17, 19);
            this.btnGuardarSE.Name = "btnGuardarSE";
            this.btnGuardarSE.Size = new System.Drawing.Size(75, 23);
            this.btnGuardarSE.TabIndex = 2;
            this.btnGuardarSE.Text = "Guardar";
            this.btnGuardarSE.UseVisualStyleBackColor = true;
            this.btnGuardarSE.Click += new System.EventHandler(this.btnGuardarSE_Click);
            // 
            // btnMostrarSE
            // 
            this.btnMostrarSE.Location = new System.Drawing.Point(132, 19);
            this.btnMostrarSE.Name = "btnMostrarSE";
            this.btnMostrarSE.Size = new System.Drawing.Size(75, 23);
            this.btnMostrarSE.TabIndex = 3;
            this.btnMostrarSE.Text = "Mostrar";
            this.btnMostrarSE.UseVisualStyleBackColor = true;
            this.btnMostrarSE.Click += new System.EventHandler(this.btnMostrarSE_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnMostrarSE);
            this.groupBox1.Controls.Add(this.btnGuardarSE);
            this.groupBox1.Location = new System.Drawing.Point(15, 60);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(213, 52);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sin Encapsulamiento";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnMostrarCE);
            this.groupBox2.Controls.Add(this.btnGuardarCE);
            this.groupBox2.Location = new System.Drawing.Point(234, 60);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(213, 52);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Con Encapsulamiento";
            // 
            // btnMostrarCE
            // 
            this.btnMostrarCE.Location = new System.Drawing.Point(132, 19);
            this.btnMostrarCE.Name = "btnMostrarCE";
            this.btnMostrarCE.Size = new System.Drawing.Size(75, 23);
            this.btnMostrarCE.TabIndex = 3;
            this.btnMostrarCE.Text = "Mostrar";
            this.btnMostrarCE.UseVisualStyleBackColor = true;
            this.btnMostrarCE.Click += new System.EventHandler(this.btnMostrarCE_Click);
            // 
            // btnGuardarCE
            // 
            this.btnGuardarCE.Location = new System.Drawing.Point(17, 19);
            this.btnGuardarCE.Name = "btnGuardarCE";
            this.btnGuardarCE.Size = new System.Drawing.Size(75, 23);
            this.btnGuardarCE.TabIndex = 2;
            this.btnGuardarCE.Text = "Guardar";
            this.btnGuardarCE.UseVisualStyleBackColor = true;
            this.btnGuardarCE.Click += new System.EventHandler(this.btnGuardarCE_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnMostrarVCE);
            this.groupBox3.Controls.Add(this.btnGuardarVCE);
            this.groupBox3.Location = new System.Drawing.Point(453, 60);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(213, 52);
            this.groupBox3.TabIndex = 6;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Validando Con Encapsulamiento";
            // 
            // btnMostrarVCE
            // 
            this.btnMostrarVCE.Location = new System.Drawing.Point(132, 19);
            this.btnMostrarVCE.Name = "btnMostrarVCE";
            this.btnMostrarVCE.Size = new System.Drawing.Size(75, 23);
            this.btnMostrarVCE.TabIndex = 3;
            this.btnMostrarVCE.Text = "Mostrar";
            this.btnMostrarVCE.UseVisualStyleBackColor = true;
            this.btnMostrarVCE.Click += new System.EventHandler(this.btnMostrarVCE_Click);
            // 
            // btnGuardarVCE
            // 
            this.btnGuardarVCE.Location = new System.Drawing.Point(17, 19);
            this.btnGuardarVCE.Name = "btnGuardarVCE";
            this.btnGuardarVCE.Size = new System.Drawing.Size(75, 23);
            this.btnGuardarVCE.TabIndex = 2;
            this.btnGuardarVCE.Text = "Guardar";
            this.btnGuardarVCE.UseVisualStyleBackColor = true;
            this.btnGuardarVCE.Click += new System.EventHandler(this.btnGuardarVCE_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 140);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtNombre);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Button btnGuardarSE;
        private System.Windows.Forms.Button btnMostrarSE;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnMostrarCE;
        private System.Windows.Forms.Button btnGuardarCE;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnMostrarVCE;
        private System.Windows.Forms.Button btnGuardarVCE;
    }
}

