﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Skins
{
    public partial class FrmConfig : Form,IObserver
    {
        
        InfoConfig ic;
        public FrmConfig()
        {
            InitializeComponent();
            ic = InfoConfig.getInstance();
            ic.addObserver(this);
            updateValues();
        }
        private void updateValues()
        {
            chkTransparent.Checked = ic.isTransparent();
            chkFade.Checked = ic.isFade();
        }



        private static FrmConfig instance;
        /// <summary>
        /// Singleton
        /// </summary>
        /// <returns>Instance</returns>
        public static FrmConfig getInstance() 
        {
            if (instance == null)
            {
                instance = new FrmConfig();
            }
            else
            {
                /*
                 * IsDisposed solo se usa para los elementos como ventanas y otros que implementen IDisposable.
                 * Pero en general solo es necesario usar un if simple.
                 */
                if (instance.IsDisposed)
                {
                    instance = new FrmConfig();
                }
            }
            return instance;
        }

        private void FrmConfig_Load(object sender, EventArgs e)
        {

        }

        private void chkFade_CheckedChanged(object sender, EventArgs e)
        {
            ic.setFade(this, chkFade.Checked);
        }

        private void chkTransparent_CheckedChanged(object sender, EventArgs e)
        {
            ic.setTransparent(this, chkTransparent.Checked);
        }

        public void changed(object sender)
        {
            if (sender == this)
            {
                // nada
            }
            else
            {
                updateValues();
            }
            
        }

        private void FrmConfig_FormClosing(object sender, FormClosingEventArgs e)
        {
            InfoConfig.getInstance().removeObserver(this);
        }
    }
}
