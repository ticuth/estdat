﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DemoListas
{
    public partial class Form1 : Form
    {
        List<float> numeros;
        public Form1()
        {
            InitializeComponent();
            numeros = new List<float>();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            try{
                numeros.Add(float.Parse(txtNumero.Text));
                txtNumero.Text = "";
                txtNumero.Focus();
            }catch(Exception ex){
                MessageBox.Show("Error: "+ex.Message);
            }
        }

        private void btnContar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Total: " + numeros.Count);
        }

        private void btnPromedio_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Promedio: " + numeros.Average());
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            try
            {
                numeros.RemoveAt(int.Parse(txtLugar.Text));
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnListar_Click(object sender, EventArgs e)
        {
            string s = "";
            for (int i=0;i<numeros.Count;i++)
            {
                s += string.Format("{0}: {1}", i ,numeros[i] )+"\r\n";
            }
            txtListado.Text = s;
        }

        private void btnSuma_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Suma: " + numeros.Sum());
        }
    }
}
