﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Skins
{
    public partial class FrmConfig2 : Form,IObserver
    {
        private static FrmConfig2 instance;
        public static FrmConfig2 getInstance()
        {
            if (instance == null)
            {
                instance = new FrmConfig2();
            }
            else
            {
                if (instance.IsDisposed)
                {
                    instance = new FrmConfig2();
                }
            }
            return instance;
        }
        public FrmConfig2()
        {
            InitializeComponent();
            InfoConfig.getInstance().addObserver(this);
            updateValues();
        }

        private void FrmConfig2_Load(object sender, EventArgs e)
        {

        }

        private void FrmConfig2_FormClosing(object sender, FormClosingEventArgs e)
        {
            InfoConfig.getInstance().removeObserver(this);
        }
        private void updateValues()
        {
            InfoConfig ic = InfoConfig.getInstance();

            cboFade.SelectedIndex = (ic.isFade() ? 1 : 0);
            cboTransparent.SelectedIndex = (ic.isTransparent() ? 1 : 0);
        }
        public void changed(object sender)
        {
            if (sender == this)
            {
            }
            else
            {
                updateValues();
            }
        }

        private void cboTransparent_SelectedIndexChanged(object sender, EventArgs e)
        {
            InfoConfig.getInstance().setTransparent(this, (cboTransparent.SelectedIndex == 0) ? false:true);
        }

        private void cboFade_SelectedIndexChanged(object sender, EventArgs e)
        {
            InfoConfig.getInstance().setFade(this, (cboFade.SelectedIndex == 0) ? false : true);
        }
    }
}
