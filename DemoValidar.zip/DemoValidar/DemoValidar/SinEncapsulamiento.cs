﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoValidar
{
    /// <summary>
    /// Clase sin Encapsulamiento
    /// </summary>
    class SinEncapsulamiento
    {
        /// <summary>
        /// Nombre (se puede asignar cualquier valor)
        /// </summary>
        public string nombre;

        /// <summary>
        /// Constructor para Clase SinEncapsulamiento
        /// </summary>
        public SinEncapsulamiento()
        {
            nombre = "";
        }
    }
}
