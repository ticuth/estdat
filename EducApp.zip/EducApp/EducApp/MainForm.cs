﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;

namespace EducApp
{
    public partial class MainForm : Form
    {
        WebClient w;
        
        bool appContinue;
        public MainForm()
        {
            InitializeComponent();
            
            w = new WebClient();
            w.DownloadStringCompleted += new DownloadStringCompletedEventHandler(w_DownloadStringCompleted);
            w.DownloadProgressChanged += new DownloadProgressChangedEventHandler(w_DownloadProgressChanged);
            appContinue = false;
        }

        void w_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            if (e.ProgressPercentage >= 0 && e.ProgressPercentage <= 100)
            {
                pbProgress.Value = e.ProgressPercentage;
            }
            else
            {
                pbProgress.Value = 0;
            }
        }

        void w_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            if (e.Error !=null)
            {
                lblStatus.Text = e.Error.Message;
                btnStart.Image = null;
            }
            else
            {
                GlobalVars.create().loadConfig(e.Result);
                lblStatus.Text = "Listo. " + GlobalVars.create().getText("info/name");
                visorNoticias1.News = GlobalVars.create().getAllNews();
                visorNoticias1.Visible = true;
                appContinue = true;
                btnStart.Text = "Continue";
                btnStart.Visible = false;
                btnStart.Image = EducApp.Properties.Resources.next;
            }
            btnStart.Enabled = true;
            
            
        }
        private void getContent(string url)
        {
            lblStatus.Text = "Espere...";
            w.Headers.Add(HttpRequestHeader.UserAgent, "Mozilla/5.0 (Windows NT 6.2; rv:32.0) Gecko/20100101 Firefox/32.0");
            
            w.DownloadStringAsync(new Uri(url+"?rnd="+DateTime.Now.Ticks));
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            visorNoticias1.Visible = false;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (appContinue == false)
            {

                btnStart.Enabled = false;
                btnStart.Image = EducApp.Properties.Resources.ajax_loader;
                getContent("https://raw.githubusercontent.com/ticuth/estdat/master/config.xml");
                //getContent("http://localhost/config.xml");
            }
            else
            {
                btnStart.Visible = false;
                GlobalVars gv = GlobalVars.create();
                foreach (NewsObject no in gv.getAllNews())
                {
                    MessageBox.Show(no.getDescription());
                }
                //MessageBox.Show(gv.getText("newslist/news/url"));
            }
        }

        private void visorNoticias1_Load(object sender, EventArgs e)
        {

        }

        
    }
}
