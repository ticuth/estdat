﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoValidar
{
    /// <summary>
    /// Maneja los errores usando encapsulamiento
    /// </summary>
    class ManejoError
    {
        /// <summary>
        /// Indica si hay error o no
        /// </summary>
        private bool _hayError;

        /// <summary>
        /// Texto del error
        /// </summary>
        private string _textoError;


        /// <summary>
        /// Constructor de ManejoError
        /// </summary>
        public ManejoError()
        {
            limpiarError();
        }

        /// <summary>
        /// Limpia el error
        /// </summary>
        public void limpiarError()
        {
            _hayError = false;
            _textoError = "";
        }


        /// <summary>
        /// Activa el error
        /// </summary>
        /// <param name="texto">Texto de error a poner</param>
        public void setError(string texto)
        {
            _hayError = true;
            _textoError = texto;
        }

        /// <summary>
        /// Regresa si hay error
        /// </summary>
        /// <returns>Regresa si hay error</returns>
        public bool getHayError()
        {
            return _hayError;
        }


        /// <summary>
        /// Regresa texto del error
        /// </summary>
        /// <returns>Regresa texto del error</returns>
        public string getTextoError()
        {
            return _textoError;
        }


    }
}
