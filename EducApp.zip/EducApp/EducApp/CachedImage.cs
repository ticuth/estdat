﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Net;
using System.IO;
namespace EducApp
{
    public class CachedImage : INotifier
    {
        Image img;
        string url;
        WebClient w;
        bool isLoading;
        bool loaded;
        private INotify notif;
        private string tmpFile;

        public CachedImage()
        {
            img = null;
            isLoading = false;
            w = new WebClient();
            w.DownloadFileCompleted += new System.ComponentModel.AsyncCompletedEventHandler(w_DownloadFileCompleted);
        }
        public void connect(INotify where)
        {
            notif = where;
        }
        public void disconnect()
        {
            notif = null;
        }
        public bool isLoaded()
        {
            return loaded;
        }
        void w_DownloadFileCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            loaded = true;
            img = Image.FromFile(tmpFile);
            if (notif != null)
            {
                notif.updated();
            }
        }
        public string getUrl()
        {
            return url;
        }
        public Image getImage()
        {
            Image i = null;
            if (isLoaded())
            {
                i = img;
            }
            return i;
        }
        public void loadImage()
        {
            if (isLoaded() == false)
            {
                if (isLoading == false)
                {
                    isLoading = true;
                    w.Headers.Add(HttpRequestHeader.UserAgent, "Mozilla/5.0 (Windows NT 6.2; rv:32.0) Gecko/20100101 Firefox/32.0");
                    
                    string path = System.Windows.Forms.Application.StartupPath + @"\tmp\";

                    if (Directory.Exists(path)==false)
                    {
                        Directory.CreateDirectory(path);
                    }
                    tmpFile = path + url.Substring(url.LastIndexOf("/") + 1);
                    w.DownloadFileAsync(new Uri(url + "?rnd=" + DateTime.Now.Ticks), tmpFile);

                }
            }
        }
        public void setUrl(string value)
        {
            url = value;
        }

        
    }
}
