﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Skins
{
    public partial class Form1 : Form,IObserver
    {
        MVentana mv;
        bool useFade;

        public Form1()
        {
            InitializeComponent();
            this.Location = new Point(300, 300);
            useFade = false;
            int val = 75;
            timer1.Interval = val;
            timer2.Interval = val;

            InfoConfig.getInstance().addObserver(this);
            InfoConfig.getInstance().setTransparent(this,true);
            
            // Usando una ruta
            mv = new MVentana(this, picMove, pictureBox1, @"c:\develop\files\2137.gif");
            
            // Usando recursos internos (Resources)
            //mv = new MVentana(this, picMove, pictureBox1, global::Skins.Properties.Resources.globe);
            updateValues(InfoConfig.getInstance());
            timer1.Start();
            

        }

        private void Form1_Load(object sender, EventArgs e)
        {

            
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            
            if (Opacity > 0)
            {
                if (useFade)
                {
                    Opacity -= 0.02;
                }
                mv.paint();
                timer1.Start();
            }
            else
            {
                timer2.Start();
            }
           
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Stop();
            if (Opacity < 1)
            {
                if (useFade)
                {
                    Opacity += 0.02;
                }
                mv.paint();
                timer2.Start();
            }
            else
            {
                timer1.Start();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void picClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void picGear_Click(object sender, EventArgs e)
        {
            // Se usa la ventana FrmConfig mediante Singleton
            FrmConfig v = FrmConfig.getInstance();
            //FrmConfig v = new FrmConfig();
            v.Show();
            FrmConfig2 v2 = FrmConfig2.getInstance();
            //FrmConfig2 v2 = new FrmConfig2();
            v2.Show();

        }

        private void updateValues(InfoConfig ic)
        {
            useFade = ic.isFade();
            if (useFade == false)
            {
                Opacity = 1;
            }

            if (ic.isTransparent())
            {
                this.BackColor = Color.DarkGray;
                this.TransparencyKey = Color.DarkGray;
            }
            else
            {
                this.BackColor = Color.DarkGray;
                this.TransparencyKey = Color.Transparent;
            }
        }
        public void changed(object sender)
        {
            if (sender == this)
            {
                // nada
            }else{
                
                updateValues(InfoConfig.getInstance());
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            InfoConfig.getInstance().removeObserver(this);
        }
    }
}
