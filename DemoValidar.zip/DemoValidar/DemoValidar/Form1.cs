﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DemoValidar
{
    public partial class Form1 : Form
    {
        SinEncapsulamiento se;
        ConEncapsulamiento ce;
        ValidandoConEncapsulamiento vce;
        public Form1()
        {
            InitializeComponent();
            se = new SinEncapsulamiento();
            ce = new ConEncapsulamiento();
            vce = new ValidandoConEncapsulamiento();
        }

        private void btnGuardarSE_Click(object sender, EventArgs e)
        {
            se.nombre = txtNombre.Text;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnMostrarSE_Click(object sender, EventArgs e)
        {
            MessageBox.Show(se.nombre);
        }

        private void btnGuardarCE_Click(object sender, EventArgs e)
        {
            ce.setNombre(txtNombre.Text);
        }

        private void btnMostrarCE_Click(object sender, EventArgs e)
        {
            MessageBox.Show(ce.getNombre());
        }

        private void btnGuardarVCE_Click(object sender, EventArgs e)
        {
            ManejoError me = vce.setNombre(txtNombre.Text);
            if (me.getHayError() == true)
            {
                MessageBox.Show("Error: " + me.getTextoError());
            }
            else
            {
                MessageBox.Show("Dato guardado correctamente");
            }
        }

        private void btnMostrarVCE_Click(object sender, EventArgs e)
        {
            MessageBox.Show(vce.getNombre());
        }
    }
}
