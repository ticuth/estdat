﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EducApp
{
    public partial class VisorNoticias : UserControl,INotify
    {
        private NewsObject[] _news;
        CachedImage[] images;
        int current;
        int currentImg;
        INotifier lastNotifier;
        public NewsObject[] News
        {
            get
            {
                return _news;
            }
            set
            {

                _news = value;
                if (_news != null)
                {

                    refreshData();
                }
            }
        }
        private void refreshData()
        {
            if (_news != null)
            {
                if (_news.Length > 0)
                {
                    lblDescription.Text = _news[current].getDescription();

                    images = _news[current].getImageUrls();

                    if (images.Length > 0)
                    {
                        if (lastNotifier != null)
                        {
                            lastNotifier.disconnect();
                        }
                        //CachedImage[] allImages = _news[current].getImageUrls();
                        if (images.Length > 0)
                        {
                            images[currentImg].connect(this);
                            picCurrent.BackgroundImage = images[currentImg].getImage();
                            images[currentImg].loadImage();
                        }
                    }
                }
            }
        }
        public VisorNoticias()
        {
            InitializeComponent();
            images = null;
            current = 0;
            currentImg = 0;
            lastNotifier = null;
        }


        private void VisorNoticias_Load(object sender, EventArgs e)
        {

        }

        public void updated()
        {
            refreshData();
        }





        public void connectedTo(INotifier sender)
        {
            lastNotifier = sender;
        }

        private void picNext_Click(object sender, EventArgs e)
        {
            if (images != null)
            {
                currentImg++;
                if (currentImg >= images.Length)
                {
                    currentImg = 0;
                }
                refreshData();
            }

        }

        private void picNextNews_Click(object sender, EventArgs e)
        {
            if (_news.Length > 0)
            {
                current++;
                if (current >= _news.Length)
                {
                    current = _news.Length - 1;
                    currentImg = 0;
                }
                refreshData();
            }
        }

        private void picPrevNews_Click(object sender, EventArgs e)
        {
            if (_news.Length > 0)
            {
                current--;
                if (current < 0)
                {
                    current = 0;
                    currentImg = 0;
                }
                refreshData();
            }
        }

        private void picPrev_Click(object sender, EventArgs e)
        {
            if (images != null)
            {
                currentImg--;
                if (currentImg <0)
                {
                    currentImg = images.Length-1;
                }
                refreshData();
            }

        }

        private void picCurrent_Click(object sender, EventArgs e)
        {
            
        }

        private void lblDescription_Click(object sender, EventArgs e)
        {
            if (_news != null)
            {
                System.Diagnostics.Process.Start(_news[current].getUrl());
            }
        }
    }
}
