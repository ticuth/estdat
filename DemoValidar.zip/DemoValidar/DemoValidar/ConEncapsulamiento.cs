﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoValidar
{
    class ConEncapsulamiento
    {
        /// <summary>
        /// Nombre a guardar
        /// </summary>
        private string _nombre;

        /// <summary>
        /// Constructor
        /// </summary>
        public ConEncapsulamiento()
        {
            _nombre = "";
        }

        /// <summary>
        /// Guarda un valor en nombre pero valida
        /// </summary>
        /// <param name="valor">valor a guardar</param>
        public void setNombre(string valor)
        {
            // Solo guarda si el valor tiene 3 o mas letras.
            if (valor.Length >= 3)
            {
                _nombre = valor;
            }
        }
        /// <summary>
        /// Regresa el nombre guardado
        /// </summary>
        /// <returns>nombre</returns>
        public string getNombre()
        {
            return _nombre;
        }

    }
}
