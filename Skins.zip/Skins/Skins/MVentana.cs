﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Imaging;
namespace Skins
{
    class MVentana
    {
        Point p;
        bool mover;
        Form ventana;
        Image img;
        Point pv;
        int totFrames;
        int frame;
        PictureBox pic;
        Bitmap bm;
        Control moveObject;
        public MVentana(Form unaVentana,Control mObject,PictureBox unPictureBox, string iPath)
        {
            basicConstruct(unaVentana, mObject, unPictureBox, iPath);
        }
        public MVentana(Form unaVentana, Control mObject, PictureBox unPictureBox, Image i)
        {
            basicConstruct(unaVentana, mObject, unPictureBox, i);
        }
        private void basicConstruct(Form unaVentana, Control mObject, PictureBox unPictureBox, Image i)
        {
            moveObject = mObject;
            pic = unPictureBox;
            frame = 0;

            ventana = unaVentana;
            p = new Point();
            pv = new Point(ventana.Location.X, ventana.Location.Y);
            mover = false;
            
            loadImage(i);

            fixWindow();
            bindEvents();
        }
        private void basicConstruct(Form unaVentana, Control mObject, PictureBox unPictureBox, string iPath)
        {
            moveObject = mObject;
            pic = unPictureBox;
            frame = 0;

            ventana = unaVentana;
            p = new Point();
            pv = new Point(ventana.Location.X, ventana.Location.Y);
            mover = false;
            
            loadImage(iPath);

            fixWindow();
            bindEvents();
        }
        private void loadImage(string path)
        {
            img = Image.FromFile(path);
            bm = new Bitmap(img.Width, img.Height);
            totFrames = 0;
            if (path.ToLower().EndsWith(".gif"))
            {
                totFrames = img.GetFrameCount(FrameDimension.Time);
            }
        }
        private void loadImage(Image i)
        {
            img = i;
            bm = new Bitmap(img.Width, img.Height);
            totFrames = 0;
            try
            {
                totFrames = img.GetFrameCount(FrameDimension.Time);
            }catch(Exception ex)
            {

            }
        }
        private void fixWindow()
        {
            ventana.BackColor = Color.DarkGray;
            ventana.TransparencyKey = Color.DarkGray;
            ventana.FormBorderStyle = FormBorderStyle.None;
            paint();
            ventana.Width = img.Width;
            ventana.Height = img.Height;
        }
        public void paint()
        {
            if (totFrames > 1)
            {
                ventana.Text = "" + frame;
                try
                {
                    img.SelectActiveFrame(FrameDimension.Time, frame++);
                    /*if (totFrames < frame)
                    {
                        totFrames++;
                    }*/
                }
                catch (Exception ex)
                {
                    ventana.Text = "Error: " + totFrames;
                }
                if (frame >= totFrames)
                {
                    frame = 0;
                }
                //pic.Image = img;
                Graphics.FromImage(bm).Clear(Color.Transparent);
                //bm.MakeTransparent(bm.GetPixel(0,0));
                Graphics.FromImage(bm).DrawImage(img, new Point(0, 0));
                pic.Image = bm;
                //ventana.i = bm;
                //ventana.Refresh();
            }
            else
            {
                pic.Image = img;
            }
        }
        private void bindEvents()
        {
            moveObject.MouseDown += new MouseEventHandler(ventana_MouseDown);
            moveObject.MouseUp += new MouseEventHandler(ventana_MouseUp);
            moveObject.MouseMove += new MouseEventHandler(ventana_MouseMove);
        }

        void ventana_MouseMove(object sender, MouseEventArgs e)
        {
            int dx = 0;
            int dy = 0;
            if (mover)
            {
                dx = e.X - p.X;
                dy = e.Y - p.Y;
                pv.X += dx;
                pv.Y += dy;
                ventana.Location = pv;
            }
        }

        void ventana_MouseUp(object sender, MouseEventArgs e)
        {
            mover = false;
        }
        

        void ventana_MouseDown(object sender, MouseEventArgs e)
        {
            mover = true;
            p.X = e.X;
            p.Y = e.Y;
        }
    }
}
