﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EducApp
{
    public class NewsObject
    {
        private string url;
        private string description;
        private List<CachedImage> imageUrls;
        public NewsObject()
        {
            imageUrls = new List<CachedImage>();

        }
        public void addImageUrl(string url)
        {
            CachedImage x = new CachedImage();
            x.setUrl(url);
            imageUrls.Add(x);
        }
        public CachedImage[] getImageUrls()
        {
            return imageUrls.ToArray();
        }
        public void setUrl(string value)
        {
            url = value;
        }
        public void setDescription(string value)
        {
            description = value;
        }
        public string getUrl()
        {
            return url;
        }
        public string getDescription()
        {
            return description;
        }
        public override string ToString()
        {
            return description;
        }
    }
}
