﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace EducApp
{
    class GlobalVars
    {
        private static GlobalVars instance;
        List<NewsObject> allNews;

        public static GlobalVars create()
        {
            if (instance == null)
            {
                instance = new GlobalVars();
            }
            return instance;
        }
        public Dictionary<string, string> vars;
        private XmlDocument xdoc;
        
        public GlobalVars()
        {
            allNews = new List<NewsObject>();
            vars = new Dictionary<string, string>();
        }
        public NewsObject[] getAllNews()
        {
            return allNews.ToArray();
        }
        public void clear()
        {
            vars.Clear();
            allNews.Clear();
        }
        private void getVars(string data)
        {
            string[] pars = data.Split('=');
            if (pars.Length == 2)
            {
                vars.Add(pars[0], pars[1]);
            }
        }
        private string getText(XmlNode n, string path)
        {
            string r = "";
            XmlNode node;
            try
            {
                node = n.SelectSingleNode(path);
                r = node.InnerText;
            }
            catch (Exception ex)
            {

            }
            return r;
        }
        public string getText(string path)
        {
            string r = "";
            XmlNode node;
            try
            {
                node = xdoc.DocumentElement.SelectSingleNode(path);
                r = node.InnerText;
            }
            catch (Exception ex)
            {

            }
            return r;
        }
        private void readNews()
        {
            try
            {
                foreach(XmlNode n in xdoc.DocumentElement.SelectNodes("newslist/news"))
                {
                    NewsObject no = new NewsObject();
                    no.setUrl(getText(n, "url"));
                    no.setDescription(getText(n, "./description"));
                    foreach (XmlNode sn in n.SelectNodes("./images/image"))
                    {
                        no.addImageUrl(sn.InnerText);
                    }
                    allNews.Add(no);
                }
            }
            catch (Exception ex)
            {
            }
        }
        public void loadConfig(string data)
        {
            clear();
            xdoc = new XmlDocument();
            
            try
            {
                xdoc.LoadXml(data);
                readNews();
            }
            catch (Exception ex)
            {
            }
        }
    }
}
