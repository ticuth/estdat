﻿namespace EducApp
{
    partial class VisorNoticias
    {
        /// <summary> 
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de componentes

        /// <summary> 
        /// Método necesario para admitir el Diseñador. No se puede modificar 
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.picNext = new System.Windows.Forms.PictureBox();
            this.picCurrent = new System.Windows.Forms.PictureBox();
            this.picPrev = new System.Windows.Forms.PictureBox();
            this.lblDescription = new System.Windows.Forms.Label();
            this.picPrevNews = new System.Windows.Forms.PictureBox();
            this.picNextNews = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picNext)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCurrent)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPrev)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPrevNews)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNextNews)).BeginInit();
            this.SuspendLayout();
            // 
            // picNext
            // 
            this.picNext.Image = global::EducApp.Properties.Resources.next2;
            this.picNext.Location = new System.Drawing.Point(499, 24);
            this.picNext.Name = "picNext";
            this.picNext.Size = new System.Drawing.Size(32, 32);
            this.picNext.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picNext.TabIndex = 2;
            this.picNext.TabStop = false;
            this.picNext.Click += new System.EventHandler(this.picNext_Click);
            // 
            // picCurrent
            // 
            this.picCurrent.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picCurrent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.picCurrent.Location = new System.Drawing.Point(57, 24);
            this.picCurrent.Name = "picCurrent";
            this.picCurrent.Size = new System.Drawing.Size(436, 177);
            this.picCurrent.TabIndex = 1;
            this.picCurrent.TabStop = false;
            this.picCurrent.Click += new System.EventHandler(this.picCurrent_Click);
            // 
            // picPrev
            // 
            this.picPrev.Image = global::EducApp.Properties.Resources.back;
            this.picPrev.Location = new System.Drawing.Point(19, 24);
            this.picPrev.Name = "picPrev";
            this.picPrev.Size = new System.Drawing.Size(32, 32);
            this.picPrev.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picPrev.TabIndex = 0;
            this.picPrev.TabStop = false;
            this.picPrev.Click += new System.EventHandler(this.picPrev_Click);
            // 
            // lblDescription
            // 
            this.lblDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDescription.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblDescription.Location = new System.Drawing.Point(57, 224);
            this.lblDescription.Name = "lblDescription";
            this.lblDescription.Size = new System.Drawing.Size(436, 147);
            this.lblDescription.TabIndex = 3;
            this.lblDescription.Click += new System.EventHandler(this.lblDescription_Click);
            // 
            // picPrevNews
            // 
            this.picPrevNews.Image = global::EducApp.Properties.Resources.back;
            this.picPrevNews.Location = new System.Drawing.Point(19, 272);
            this.picPrevNews.Name = "picPrevNews";
            this.picPrevNews.Size = new System.Drawing.Size(32, 32);
            this.picPrevNews.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picPrevNews.TabIndex = 4;
            this.picPrevNews.TabStop = false;
            this.picPrevNews.Click += new System.EventHandler(this.picPrevNews_Click);
            // 
            // picNextNews
            // 
            this.picNextNews.Image = global::EducApp.Properties.Resources.next2;
            this.picNextNews.Location = new System.Drawing.Point(499, 272);
            this.picNextNews.Name = "picNextNews";
            this.picNextNews.Size = new System.Drawing.Size(32, 32);
            this.picNextNews.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picNextNews.TabIndex = 5;
            this.picNextNews.TabStop = false;
            this.picNextNews.Click += new System.EventHandler(this.picNextNews_Click);
            // 
            // VisorNoticias
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.picNextNews);
            this.Controls.Add(this.picPrevNews);
            this.Controls.Add(this.lblDescription);
            this.Controls.Add(this.picNext);
            this.Controls.Add(this.picCurrent);
            this.Controls.Add(this.picPrev);
            this.MinimumSize = new System.Drawing.Size(547, 385);
            this.Name = "VisorNoticias";
            this.Size = new System.Drawing.Size(547, 385);
            this.Load += new System.EventHandler(this.VisorNoticias_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picNext)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCurrent)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPrev)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picPrevNews)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picNextNews)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox picPrev;
        private System.Windows.Forms.PictureBox picCurrent;
        private System.Windows.Forms.PictureBox picNext;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.PictureBox picPrevNews;
        private System.Windows.Forms.PictureBox picNextNews;
    }
}
